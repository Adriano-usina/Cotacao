export default function Fornecedores() {
  return (
    <div>
      
<nav style={{ padding: '10px', background: '#eee' }}>
  <a href="/painel">Painel</a> | 
  <a href="/fornecedores">Fornecedores</a> | 
  <a href="/veiculos">Veículos</a> | 
  <a href="/fretes">Fretes</a> | 
  <a href="/coletas">Coletas</a> | 
  <a href="/entregas">Entregas</a> | 
  <a href="/relatorios">Relatórios</a> | 
  <a href="/login">Login</a>
</nav>

      <h1>Fornecedores</h1>
      <p>Conteúdo da página de fornecedores.</p>
    </div>
  );
}
