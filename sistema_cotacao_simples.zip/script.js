function mostrarCotacao() {
  document.getElementById('resultado').innerText = 'R$ 154,90 - Cotação Simulada';
}
